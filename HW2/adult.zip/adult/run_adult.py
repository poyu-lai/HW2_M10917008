import csv
import numpy as np
import algorithm
'''
adult dataset

1. age: continuous.
2. workclass: Private, Self-emp-not-inc, Self-emp-inc, Federal-gov, Local-gov, State-gov, Without-pay, Never-worked.
3. fnlwgt: continuous.
4. education: Bachelors, Some-college, 11th, HS-grad, Prof-school, Assoc-acdm, Assoc-voc, 9th, 7th-8th, 12th, Masters, 1st-4th, 10th, Doctorate, 5th-6th, Preschool.
5. education-num: continuous.
6. marital-status: Married-civ-spouse, Divorced, Never-married, Separated, Widowed, Married-spouse-absent, Married-AF-spouse.
7. occupation: Tech-support, Craft-repair, Other-service, Sales, Exec-managerial, Prof-specialty, Handlers-cleaners, Machine-op-inspct, Adm-clerical, Farming-fishing, Transport-moving, Priv-house-serv, Protective-serv, Armed-Forces.
8. relationship: Wife, Own-child, Husband, Not-in-family, Other-relative, Unmarried.
9. race: White, Asian-Pac-Islander, Amer-Indian-Eskimo, Other, Black.
10. sex: Female, Male.
11. capital-gain: continuous.
12. capital-loss: continuous.
13. hours-per-week: continuous.
14. native-country: United-States, Cambodia, England, Puerto-Rico, Canada, Germany, Outlying-US(Guam-USVI-etc), India, Japan, Greece, South, China, Cuba, Iran, Honduras, Philippines, Italy, Poland, Jamaica, Vietnam, Mexico, Portugal, Ireland, France, Dominican-Republic, Laos, Ecuador, Taiwan, Haiti, Columbia, Hungary, Guatemala, Nicaragua, Scotland, Thailand, Yugoslavia, El-Salvador, Trinadad&Tobago, Peru, Hong, Holand-Netherlands.
15. >50K, <=50K.
'''

workclass = ['Private', 'Self-emp-not-inc', 'Self-emp-inc', 'Federal-gov', 
                    'Local-gov', 'State-gov', 'Without-pay', 'Never-worked','?']
education = ['Bachelors', 'Some-college', '11th', 'HS-grad', 'Prof-school', 
                    'Assoc-acdm', 'Assoc-voc', '9th', '7th-8th', '12th', 'Masters', 
                    '1st-4th', '10th', 'Doctorate', '5th-6th', 'Preschool','?']
marital_status = ['Married-civ-spouse', 'Divorced', 'Never-married', 'Separated', 'Widowed', 
                    'Married-spouse-absent', 'Married-AF-spouse','?']
occupation = ['Tech-support', 'Craft-repair', 'Other-service', 'Sales', 'Exec-managerial', 
                'Prof-specialty', 'Handlers-cleaners', 'Machine-op-inspct', 'Adm-clerical', 
                'Farming-fishing', 'Transport-moving', 'Priv-house-serv', 'Protective-serv', 
                'Armed-Forces','?']
relationship = ['Wife', 'Own-child', 'Husband', 'Not-in-family', 'Other-relative', 
                'Unmarried','?']
race = ['White', 'Asian-Pac-Islander', 'Amer-Indian-Eskimo', 'Other', 'Black','?']
sex = ['Female', 'Male','?']
native_country = ['United-States', 'Cambodia', 'England', 'Puerto-Rico', 'Canada', 
                    'Germany', 'Outlying-US(Guam-USVI-etc)', 'India', 'Japan', 'Greece', 
                    'South', 'China', 'Cuba', 'Iran', 'Honduras', 'Philippines', 'Italy', 
                    'Poland', 'Jamaica', 'Vietnam', 'Mexico', 'Portugal', 'Ireland', 
                    'France', 'Dominican-Republic', 'Laos', 'Ecuador', 'Taiwan', 
                    'Haiti', 'Columbia', 'Hungary', 'Guatemala', 'Nicaragua', 'Scotland', 
                    'Thailand', 'Yugoslavia', 'El-Salvador', 'Trinadad&Tobago', 'Peru', 
                    'Hong', 'Holand-Netherlands','?']
result = ['>50K', '<=50K']


# train資料準備
train_x = [] 
train_y = []
with open('adult_prepare_train.csv', 'r') as csvfile:
    rows = csv.reader(csvfile)
    for row_data in rows:
        ch_data = row_data[:-3] + row_data[-2:]
        train_x.append(ch_data)
        train_y.append(row_data[-3])

train_x = np.array(train_x, dtype='float')
train_y = np.array(train_y, dtype='float')

#正規化
# train_x = train_x/np.max(train_x, 0)
train_x = train_x/np.mean(train_x, 0)
print('train data')
print(train_y)
print(train_x)


# test資料準備
test_x = [] 
test_y = []
with open('adult_prepare_test.csv', 'r') as csvfile:
    rows = csv.reader(csvfile)
    for row_data in rows:
        ch_data = row_data[:-3] + row_data[-2:]
        test_x.append(ch_data)
        test_y.append(row_data[-3])


test_x = np.array(test_x, dtype='float')
test_y = np.array(test_y, dtype='float')

#正規化
# test_x = test_x/np.max(test_x, 0)
test_x = test_x/np.mean(test_x, 0)
print('test data')
print(test_y)
print(test_x)

# 模型準備
use_models = []
use_models.append(algorithm.NerualNetwork(len(test_x[0])))
use_models.append(algorithm.SVR())
use_models.append(algorithm.XGBoost())
use_models.append(algorithm.RandomForest())

result_RMSE=[]
result_MAPE=[]
for using_model in use_models:
    #訓練
    print(using_model.name)
    print('start train')
    using_model.train(train_x, train_y)
    print('train finished')

    # #訓練集預測
    # print(train_y)
    # predicts_train = using_model.predict(train_x)
    # print(predicts_train)
    # #訓練集預測結果存取
    # with open('adult'+using_model.name+'_predict_train.csv', 'w', newline='') as csvfile:
    #     writer = csv.writer(csvfile)
    #     writer.writerow(['預測類別','正確類別'])
    #     for i in range(len(predicts_train)):
    #         writer.writerow([result[int(predicts_train[i])], result[int(train_y[i])]])

    # #訓練集預測的錯誤率
    # error=0.0
    # for i in range(len(predicts_train)):
    #     if predicts_train[i] != train_y[i]:
    #         error+=1

    # error_rate = error/len(predicts_train)
    # print('train error rate:', error_rate)


    #測試集預測
    print(test_y)
    predicts_test = using_model.predict(test_x)
    print(predicts_test)
    #訓練集預測結果存取
    with open('adult_'+using_model.name+'predict_test.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['預測類別','正確類別'])
        for i in range(len(predicts_test)):
            writer.writerow([predicts_test[i][0], int(test_y[i])])

    #測試集預測的錯誤率
    # error=0.0
    # for i in range(len(predicts_test)):
    #     if predicts_test[i] != test_y[i]:
    #         error+=1
    # error_rate = error/len(predicts_test)
    # print('test error rate:', error_rate)

    # error=0.0
    # for i in range(len(predicts_test)):
    #     if int(predicts_test[i]) != int(test_y[i]):
    #         error+=1
    # error_rate = error/len(predicts_test)
    # print('test error rate:', error_rate)



    #測試集預測的錯誤率
    #RMSE
    error_rate = np.sqrt(np.mean(np.power(predicts_test-test_y, 2)))
    result_RMSE.append(error_rate)
    print(using_model.name+' RMSE:', error_rate)
    #MAPE
    error_rate = np.mean(np.absolute(predicts_test-test_y)/test_y)
    result_MAPE.append(error_rate)
    print(using_model.name+' MAPE:', error_rate*100, '%')
    print('-----------------------------------')