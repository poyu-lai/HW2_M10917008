import csv
from sklearn import tree
import numpy as np
'''
adult dataset

1. age: continuous.
2. workclass: Private, Self-emp-not-inc, Self-emp-inc, Federal-gov, Local-gov, State-gov, Without-pay, Never-worked.
3. fnlwgt: continuous.
4. education: Bachelors, Some-college, 11th, HS-grad, Prof-school, Assoc-acdm, Assoc-voc, 9th, 7th-8th, 12th, Masters, 1st-4th, 10th, Doctorate, 5th-6th, Preschool.
5. education-num: continuous.
6. marital-status: Married-civ-spouse, Divorced, Never-married, Separated, Widowed, Married-spouse-absent, Married-AF-spouse.
7. occupation: Tech-support, Craft-repair, Other-service, Sales, Exec-managerial, Prof-specialty, Handlers-cleaners, Machine-op-inspct, Adm-clerical, Farming-fishing, Transport-moving, Priv-house-serv, Protective-serv, Armed-Forces.
8. relationship: Wife, Own-child, Husband, Not-in-family, Other-relative, Unmarried.
9. race: White, Asian-Pac-Islander, Amer-Indian-Eskimo, Other, Black.
10. sex: Female, Male.
11. capital-gain: continuous.
12. capital-loss: continuous.
13. hours-per-week: continuous.
14. native-country: United-States, Cambodia, England, Puerto-Rico, Canada, Germany, Outlying-US(Guam-USVI-etc), India, Japan, Greece, South, China, Cuba, Iran, Honduras, Philippines, Italy, Poland, Jamaica, Vietnam, Mexico, Portugal, Ireland, France, Dominican-Republic, Laos, Ecuador, Taiwan, Haiti, Columbia, Hungary, Guatemala, Nicaragua, Scotland, Thailand, Yugoslavia, El-Salvador, Trinadad&Tobago, Peru, Hong, Holand-Netherlands.
15. >50K, <=50K.
'''

workclass = ['Private', 'Self-emp-not-inc', 'Self-emp-inc', 'Federal-gov', 
                    'Local-gov', 'State-gov', 'Without-pay', 'Never-worked','?']
education = ['Bachelors', 'Some-college', '11th', 'HS-grad', 'Prof-school', 
                    'Assoc-acdm', 'Assoc-voc', '9th', '7th-8th', '12th', 'Masters', 
                    '1st-4th', '10th', 'Doctorate', '5th-6th', 'Preschool','?']
marital_status = ['Married-civ-spouse', 'Divorced', 'Never-married', 'Separated', 'Widowed', 
                    'Married-spouse-absent', 'Married-AF-spouse','?']
occupation = ['Tech-support', 'Craft-repair', 'Other-service', 'Sales', 'Exec-managerial', 
                'Prof-specialty', 'Handlers-cleaners', 'Machine-op-inspct', 'Adm-clerical', 
                'Farming-fishing', 'Transport-moving', 'Priv-house-serv', 'Protective-serv', 
                'Armed-Forces','?']
relationship = ['Wife', 'Own-child', 'Husband', 'Not-in-family', 'Other-relative', 
                'Unmarried','?']
race = ['White', 'Asian-Pac-Islander', 'Amer-Indian-Eskimo', 'Other', 'Black','?']
sex = ['Female', 'Male','?']
native_country = ['United-States', 'Cambodia', 'England', 'Puerto-Rico', 'Canada', 
                    'Germany', 'Outlying-US(Guam-USVI-etc)', 'India', 'Japan', 'Greece', 
                    'South', 'China', 'Cuba', 'Iran', 'Honduras', 'Philippines', 'Italy', 
                    'Poland', 'Jamaica', 'Vietnam', 'Mexico', 'Portugal', 'Ireland', 
                    'France', 'Dominican-Republic', 'Laos', 'Ecuador', 'Taiwan', 
                    'Haiti', 'Columbia', 'Hungary', 'Guatemala', 'Nicaragua', 'Scotland', 
                    'Thailand', 'Yugoslavia', 'El-Salvador', 'Trinadad&Tobago', 'Peru', 
                    'Hong', 'Holand-Netherlands','?']
result = ['>50K', '<=50K']
result_test = ['>50K.', '<=50K.']

#train 
prepare_adult_datas=[]
with open('adult.data', 'r') as csvfile:
    rows = csv.reader(csvfile)

    for row_data in rows:
        prepare_adult_datas.append([int(row_data[0]),
                            workclass.index(row_data[1][1:]),
                            int(row_data[2]),
                            education.index(row_data[3][1:]),
                            int(row_data[4]),
                            marital_status.index(row_data[5][1:]),
                            occupation.index(row_data[6][1:]),
                            relationship.index(row_data[7][1:]),
                            race.index(row_data[8][1:]),
                            sex.index(row_data[9][1:]),
                            int(row_data[10]),
                            int(row_data[11]),
                            int(row_data[12]),
                            native_country.index(row_data[13][1:]),
                            result.index(row_data[14][1:]),
                            ])

with open('adult_prepare_train.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    for prepare_row_data in prepare_adult_datas:
        writer.writerow(prepare_row_data)

print(prepare_adult_datas)
print(len(prepare_adult_datas))


#test
prepare_adult_datas=[]
with open('adult.test', 'r') as csvfile:
    rows = csv.reader(csvfile)

    for row_data in rows:
        prepare_adult_datas.append([int(row_data[0]),
                            workclass.index(row_data[1][1:]),
                            int(row_data[2]),
                            education.index(row_data[3][1:]),
                            int(row_data[4]),
                            marital_status.index(row_data[5][1:]),
                            occupation.index(row_data[6][1:]),
                            relationship.index(row_data[7][1:]),
                            race.index(row_data[8][1:]),
                            sex.index(row_data[9][1:]),
                            int(row_data[10]),
                            int(row_data[11]),
                            int(row_data[12]),
                            native_country.index(row_data[13][1:]),
                            result_test.index(row_data[14][1:]),
                            ])

with open('adult_prepare_test.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    for prepare_row_data in prepare_adult_datas:
        writer.writerow(prepare_row_data)

print(prepare_adult_datas)
print(len(prepare_adult_datas))

