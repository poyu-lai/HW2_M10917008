from keras.models import Sequential         # nerual
from keras.layers import Dense              # nerual
import keras                                # nerual
from sklearn import svm                     # svr
from sklearn import ensemble                # randomforest
from xgboost import XGBClassifier           # xgboost
import numpy as np
class NerualNetwork:
    def __init__(self, input_size):
        self.name = 'nerual network'
        self.input_size = input_size
        

    def nn_model(self):
        self.model = Sequential()
        self.model.add(Dense(256, input_dim=self.input_size, activation='relu'))
        self.model.add(Dense(16, activation='relu'))
        # self.model.add(Dense(1, activation='sigmoid'))
        self.model.add(Dense(1, activation='relu'))
        optimizer = keras.optimizers.Adam(learning_rate=1e-2)
        self.model.compile(optimizer=optimizer, loss='mean_squared_error', metrics=['accuracy'])
        # self.model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

    def soft_model(self, out_len):
        self.model = Sequential()
        self.model.add(Dense(256, input_dim=self.input_size, activation='relu'))
        self.model.add(Dense(16, activation='relu'))
        # self.model.add(Dense(16, activation='relu'))
        self.model.add(Dense(out_len, activation='softmax'))
        optimizer = keras.optimizers.Adam(learning_rate=1e-2)
        self.model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

    def train(self, train_x, train_y):
        # self.soft_model(np.max(train_y))
        # train_y = train_y.astype(int)
        # print(np.arange(np.max(train_y)))
        # onehot_y = train_y[:, np.newaxis] == np.arange(np.max(train_y))
        # print(onehot_y)
        # print(np.where(onehot_y == True))
        # self.model.fit(x=train_x, y=onehot_y, epochs=10)
        self.nn_model()
        self.model.fit(x=train_x, y=train_y, epochs=100)

    def predict(self, test_x):
        predict_y = self.model.predict(test_x)
        # print(np.argmax(predict_y,1))
        # predict_y = np.argmax(predict_y,1)
        return predict_y


class SVR:
    def __init__(self):
        self.name = 'svr'
        self.svr = svm.SVR(kernel='rbf')

    def train(self, train_x, train_y):
        self.svr.fit(train_x, train_y)

    def predict(self, test_x):
        predict_y = self.svr.predict(test_x)
        return predict_y


class RandomForest:
    def __init__(self):
        self.name = 'random forest'
        self.forest = ensemble.RandomForestClassifier(n_estimators = 100)

    def train(self, train_x, train_y):
        self.forest.fit(train_x, train_y)

    def predict(self, test_x):
        predict_y = self.forest.predict(test_x)
        return predict_y


class XGBoost:
    def __init__(self):
        self.name = 'xgboost'
        self.xgb = XGBClassifier(tree_method='gpu_hist')
    
    def train(self, train_x, train_y):
        self.xgb.fit(train_x, train_y)    

    def predict(self, test_x):
        predict_y = self.xgb.predict(test_x)
        return predict_y