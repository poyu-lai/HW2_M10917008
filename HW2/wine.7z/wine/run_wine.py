import csv
import numpy as np
import algorithm
'''
1.wine dataset
2.fixed acidity
3.volatile acidity
4.citric acid
5.residual sugar
6.chlorides
7.free sulfur dioxide
8.total sulfur dioxide
9.density
10.pH
11.sulphates
12.alcohol
13.quality
'''

# 從data檔案中取資料
data_x = [] 
data_y = []
row_info=[]
firstrow = True
with open('winequality-red.csv', 'r') as csvfile:
    rows = csv.reader(csvfile, delimiter=';')
    row_info = next(rows)  #文字欄位
    for row_data in rows:
        print(row_data)
        data_x.append(np.array(row_data[:-1]))
        data_y.append(row_data[-1])

 
data_x = np.array(data_x, dtype=np.float)
# train_x = train_x.astype(np.float)
data_y = np.array(data_y, dtype='float')

#資料分割成train和test
print(len(data_x))
data_size_segament = int(len(data_x)/5*4)
# print(int(data_size_segament))
train_x = data_x[:data_size_segament]
train_y = data_y[:data_size_segament]
test_x = data_x[data_size_segament:]
test_y = data_y[data_size_segament:]


#正規化
# train_x = train_x/np.max(train_x, 0)
train_x = train_x/np.mean(train_x, 0)
print('train data')
print(train_y)
print(train_x)

# test_x = test_x/np.max(test_x, 0)
test_x = test_x/np.mean(test_x, 0)
print('test data')
print(test_y)
print(test_x)

# 模型準備
use_models = []
use_models.append(algorithm.NerualNetwork(len(test_x[0])))
use_models.append(algorithm.SVR())
use_models.append(algorithm.XGBoost())
use_models.append(algorithm.RandomForest())

result_RMSE=[]
result_MAPE=[]
for using_model in use_models:
    #訓練
    print(using_model.name)
    print('start train')
    using_model.train(train_x, train_y)
    print('train finished')

    # #訓練集預測
    # print(train_y)
    # predicts_train = using_model.predict(train_x)
    # print(predicts_train)
    # #訓練集預測結果存取
    # with open('adult'+using_model.name+'_predict_train.csv', 'w', newline='') as csvfile:
    #     writer = csv.writer(csvfile)
    #     writer.writerow(['預測類別','正確類別'])
    #     for i in range(len(predicts_train)):
    #         writer.writerow([result[int(predicts_train[i])], result[int(train_y[i])]])

    # #訓練集預測的錯誤率
    # error=0.0
    # for i in range(len(predicts_train)):
    #     if predicts_train[i] != train_y[i]:
    #         error+=1

    # error_rate = error/len(predicts_train)
    # print('train error rate:', error_rate)


    #測試集預測
    # print(test_y)
    predicts_test = using_model.predict(test_x)
    # print(predicts_test)
    #訓練集預測結果存取
    with open('winequality-red'+using_model.name+'predict_test.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['預測類別','正確類別'])
        for i in range(len(predicts_test)):
            writer.writerow([predicts_test[i], int(test_y[i])])

    #測試集預測的錯誤率
    # error=0.0
    # for i in range(len(predicts_test)):
    #     if predicts_test[i] != test_y[i]:
    #         error+=1
    # error_rate = error/len(predicts_test)
    # print('test error rate:', error_rate)

    # error=0.0
    # for i in range(len(predicts_test)):
    #     if int(predicts_test[i]) != int(test_y[i]):
    #         error+=1
    # error_rate = error/len(predicts_test)
    # print('test error rate:', error_rate)



    #測試集預測的錯誤率
    #RMSE
    error_rate = np.sqrt(np.mean(np.power(predicts_test-test_y, 2)))
    result_RMSE.append(error_rate)
    print(using_model.name+' RMSE:', error_rate)
    #MAPE
    error_rate = np.mean(np.absolute(predicts_test-test_y)/test_y)
    result_MAPE.append(error_rate)
    print(using_model.name+' MAPE:', error_rate*100, '%')
    print('-----------------------------------')